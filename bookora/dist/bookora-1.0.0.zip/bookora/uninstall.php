<?php
/**
 * Uninstall routine. Data is only removed when the user opted in via settings.
 *
 * @package Bookora
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

require_once __DIR__ . '/src/autoload.php';

/**
 * Remove Bookora data for the current site if requested.
 */
function bookora_uninstall_site(): void {
	global $wpdb;

	// Scheduled tasks are always removed – the plugin code is gone.
	wp_clear_scheduled_hook( 'bookora_daily_maintenance' );
	wp_clear_scheduled_hook( 'bookora_send_reminders' );
	wp_clear_scheduled_hook( 'bookora_send_reminders_more' );
	wp_clear_scheduled_hook( 'bookora_mail_queue' );
	delete_option( 'bookora_mail_queue_lock' );
	wp_clear_scheduled_hook( 'bookora_sync_calendars' );

	$settings = get_option( 'bookora_settings', array() );
	if ( empty( $settings['delete_on_uninstall'] ) ) {
		return;
	}

	// Private uploads (files and signatures): only Bookora's own folder, only regular files.
	$bookora_uploads = wp_upload_dir( null, false );
	$bookora_dir     = trailingslashit( (string) $bookora_uploads['basedir'] ) . 'bookora-private';
	if ( is_dir( $bookora_dir ) ) {
		$bookora_items = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $bookora_dir, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
		foreach ( $bookora_items as $bookora_item ) {
			if ( $bookora_item->isLink() ) {
				continue;
			}
			$bookora_item->isDir() ? @rmdir( $bookora_item->getPathname() ) : wp_delete_file( $bookora_item->getPathname() ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
		}
		@rmdir( $bookora_dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
	}

	foreach ( \Bookora\Install\Schema::TABLES as $name ) {
		$table = \Bookora\Install\Schema::table( $wpdb->prefix, $name );
		$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- internal table names.
	}

	delete_option( 'bookora_settings' );
	delete_option( 'bookora_db_version' );
	delete_option( 'bookora_feed_tokens' );
	delete_option( 'bookora_integrations' );
	// Remaining options and short-lived caches (rate limits, tokens) of the plugin.
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s", 'bookora\_%', '\_transient\_bookora\_%', '\_transient\_timeout\_bookora\_%' ) );
	\Bookora\Security\Capabilities::uninstall();
}

if ( is_multisite() ) {
	foreach ( get_sites( array( 'fields' => 'ids' ) ) as $bookora_site_id ) {
		switch_to_blog( (int) $bookora_site_id );
		bookora_uninstall_site();
		restore_current_blog();
	}
} else {
	bookora_uninstall_site();
}
